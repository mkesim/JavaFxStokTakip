package application;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import javafx.scene.control.TableColumn;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import java.nio.file.StandardOpenOption;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableView;
import javafx.stage.Stage;

public class AnaEkranController {
    @FXML
    private TableView<Ürün> urunTable;

    private ObservableList<Ürün> urunListesi;

    @FXML
    void initialize() {
        urunListesi = FXCollections.observableArrayList();
        urunTable.setItems(urunListesi);

        // Set up cell value factories for table columns
        TableColumn<Ürün, String> urunAdiColumn = (TableColumn<Ürün, String>) urunTable.getColumns().get(0);
        urunAdiColumn.setCellValueFactory(cellData -> cellData.getValue().urunAdiProperty());

        TableColumn<Ürün, Number> fiyatColumn = (TableColumn<Ürün, Number>) urunTable.getColumns().get(1);
        fiyatColumn.setCellValueFactory(cellData -> cellData.getValue().fiyatProperty());

        TableColumn<Ürün, Number> miktarColumn = (TableColumn<Ürün, Number>) urunTable.getColumns().get(2);
        miktarColumn.setCellValueFactory(cellData -> cellData.getValue().miktarProperty());

        // TODO: veri.csv dosyasından ürünleri oku ve urunListesi'ne ekle
        // Örnek olarak, aşağıdaki kodu kullanabilirsiniz:
        
        try {
            Path path = Paths.get("veri.csv");
            if (!Files.exists(path)) {
                Files.createFile(path);
                Files.write(path, "urunAdi,fiyat,miktar\n".getBytes());
            }
            List<String> lines = Files.readAllLines(path);
            for (int i = 1; i < lines.size(); i++) {
                String line = lines.get(i);
                String[] parts = line.split(",");
                if (parts.length < 3) continue;
                String urunAdi = parts[0];
                double fiyat = Double.parseDouble(parts[1]);
                int miktar = Integer.parseInt(parts[2]);
                Ürün urun = new Ürün(urunAdi, fiyat, miktar);
                urunListesi.add(urun);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        
    }


    @FXML
    void urunEkle(ActionEvent event) {
        // TODO: Ürün ekleme ekranını görüntüle
        // Örnek olarak, aşağıdaki kodu kullanabilirsiniz:
        
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("UrunEkle.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.showAndWait();

            UrunEkleController controller = loader.getController();
            Ürün urun = controller.getUrun();
            if (urun != null) {
                urunListesi.add(urun);
                System.out.println(urunListesi); // print the contents of the urunListesi list

                // Add product to veri.csv file
                String urunAdi = urun.getUrunAdi();
                double fiyat = urun.getFiyat();
                int miktar = urun.getMiktar();
                String line = urunAdi + "," + fiyat + "," + miktar + "\n";
                Files.write(Paths.get("veri.csv"), line.getBytes(), StandardOpenOption.APPEND);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        
    }

    @FXML
    void urunSil(ActionEvent event) {
        Ürün seciliUrun = urunTable.getSelectionModel().getSelectedItem();
        if (seciliUrun != null) {
            urunListesi.remove(seciliUrun);

            // Delete product from veri.csv file
            try {
                Path path = Paths.get("veri.csv");
                List<String> lines = Files.readAllLines(path);
                String urunAdi = seciliUrun.getUrunAdi();
                lines.removeIf(line -> line.startsWith(urunAdi + ","));
                Files.write(path, lines);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    @FXML
    void urunGuncelle(ActionEvent event) {
        // TODO: Ürün güncelleme ekranını görüntüle
        // Örnek olarak, aşağıdaki kodu kullanabilirsiniz:
        
        Ürün seciliUrun = urunTable.getSelectionModel().getSelectedItem();
        if (seciliUrun != null) {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("UrunGuncelle.fxml"));
                Parent root = loader.load();
                Scene scene = new Scene(root);
                Stage stage = new Stage();
                stage.setScene(scene);

                UrunGuncelleController controller = loader.getController();
                controller.setUrun(seciliUrun);

                stage.showAndWait();

                // Update product in veri.csv file
                Path path = Paths.get("veri.csv");
                List<String> lines = Files.readAllLines(path);
                String urunAdi = seciliUrun.getUrunAdi();
                double fiyat = seciliUrun.getFiyat();
                int miktar = seciliUrun.getMiktar();
                for (int i = 0; i < lines.size(); i++) {
                    if (lines.get(i).startsWith(urunAdi + ",")) {
                        lines.set(i, urunAdi + "," + fiyat + "," + miktar);
                        break;
                    }
                }
                Files.write(path, lines);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        
    }

}
