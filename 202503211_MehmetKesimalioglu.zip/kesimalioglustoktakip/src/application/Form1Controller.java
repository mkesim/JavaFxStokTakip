package application;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.nio.file.Path;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class Form1Controller {
    @FXML
    private TextField kullaniciAdiField;

    @FXML
    private TextField sifreField;

    @FXML
    private void girisYap() {
        String kullaniciAdi = kullaniciAdiField.getText();
        String sifre = sifreField.getText();

        if (kullaniciDogrula(kullaniciAdi, sifre)) {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("AnaEkran.fxml"));
                Parent root = loader.load();
                Scene scene = new Scene(root);
                Stage stage = new Stage();
                stage.setScene(scene);
                stage.show();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            // TODO: Hata mesajı göster
        }
    }

    private boolean kullaniciDogrula(String kullaniciAdi, String sifre) {
        try {
            Path path = Paths.get("kullanici.csv");
            if (!Files.exists(path)) {
                Files.createFile(path);
                Files.write(path, "kullaniciAdi,sifre\nornek,sifre\n".getBytes());
            }
            List<String> lines = Files.readAllLines(path);
            for (String line : lines) {
                String[] parts = line.split(",");
                if (parts[0].equals(kullaniciAdi) && parts[1].equals(sifre)) {
                    return true;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

}
