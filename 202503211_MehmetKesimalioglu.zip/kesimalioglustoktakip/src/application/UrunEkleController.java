package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class UrunEkleController {
    @FXML
    private TextField urunAdiField;

    @FXML
    private TextField fiyatField;

    @FXML
    private TextField miktarField;

    private Ürün urun;

    @FXML
    void urunEkle(ActionEvent event) {
        String urunAdi = urunAdiField.getText();
        double fiyat = Double.parseDouble(fiyatField.getText());
        int miktar = Integer.parseInt(miktarField.getText());
        urun = new Ürün(urunAdi, fiyat, miktar);

        Stage stage = (Stage) urunAdiField.getScene().getWindow();
        stage.close();
    }

    public Ürün getUrun() {
        return urun;
    }
}
