package application;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Ürün {
    private final StringProperty urunAdi;
    private final DoubleProperty fiyat;
    private final IntegerProperty miktar;

    public Ürün(String urunAdi, double fiyat, int miktar) {
        this.urunAdi = new SimpleStringProperty(urunAdi);
        this.fiyat = new SimpleDoubleProperty(fiyat);
        this.miktar = new SimpleIntegerProperty(miktar);
    }

    public String getUrunAdi() {
        return urunAdi.get();
    }

    public void setUrunAdi(String urunAdi) {
        this.urunAdi.set(urunAdi);
    }

    public StringProperty urunAdiProperty() {
        return urunAdi;
    }

    public double getFiyat() {
        return fiyat.get();
    }

    public void setFiyat(double fiyat) {
        this.fiyat.set(fiyat);
    }

    public DoubleProperty fiyatProperty() {
        return fiyat;
    }

    public int getMiktar() {
        return miktar.get();
    }

    public void setMiktar(int miktar) {
        this.miktar.set(miktar);
    }

    public IntegerProperty miktarProperty() {
        return miktar;
    }
}
