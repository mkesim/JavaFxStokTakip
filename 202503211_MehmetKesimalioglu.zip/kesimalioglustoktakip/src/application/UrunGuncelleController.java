package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class UrunGuncelleController {
    @FXML
    private TextField urunAdiField;

    @FXML
    private TextField fiyatField;

    @FXML
    private TextField miktarField;

    private Ürün urun;

    public void setUrun(Ürün urun) {
        this.urun = urun;
        urunAdiField.setText(urun.getUrunAdi());
        fiyatField.setText(String.valueOf(urun.getFiyat()));
        miktarField.setText(String.valueOf(urun.getMiktar()));
    }

    @FXML
    void urunGuncelle(ActionEvent event) {
        String urunAdi = urunAdiField.getText();
        double fiyat = Double.parseDouble(fiyatField.getText());
        int miktar = Integer.parseInt(miktarField.getText());
        urun.setUrunAdi(urunAdi);
        urun.setFiyat(fiyat);
        urun.setMiktar(miktar);

        Stage stage = (Stage) urunAdiField.getScene().getWindow();
        stage.close();
    }
}
